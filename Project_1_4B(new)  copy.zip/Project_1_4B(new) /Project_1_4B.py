import pandas as pd

c = pd.read_csv('orderdata_sample.csv')
print(c)

c['Total'] = c['Quantity'] * c['Price'] + c['Freight']
print(c)

c.to_csv("orderdata_sample(additional).csv")

c = pd.read_csv('orderdata_sample(additional).csv')

print(c["OrderID"], c["CustomerID"], c["Total"])

